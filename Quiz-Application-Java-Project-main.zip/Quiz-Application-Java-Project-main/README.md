# Quiz-Application-Java-Project

## Video Output:

https://github.com/rajdeep-codes/Quiz-Application-Java-Project/assets/121939861/4822f71e-296f-4bf4-8383-f8d01e20b290


## Screenshots:

## Login Class:
![01 07 2024_23 08 43_REC](https://github.com/rajdeep-codes/Quiz-Application-Java-Project/assets/121939861/f856fb1b-ecee-4ace-903d-e1633ac77b12)

## Rules Class:

![01 07 2024_23 09 32_REC](https://github.com/rajdeep-codes/Quiz-Application-Java-Project/assets/121939861/2aba0d29-e52e-4a6b-9588-e7d870d52c4a)

## Quiz Class:

![01 07 2024_23 10 16_REC](https://github.com/rajdeep-codes/Quiz-Application-Java-Project/assets/121939861/fcfae49c-d860-4297-a63a-f2bb8d951bc1)

## Score Class:

![01 07 2024_23 11 00_REC](https://github.com/rajdeep-codes/Quiz-Application-Java-Project/assets/121939861/74e37730-f0c9-47cb-86d0-936e7c9c744a)
